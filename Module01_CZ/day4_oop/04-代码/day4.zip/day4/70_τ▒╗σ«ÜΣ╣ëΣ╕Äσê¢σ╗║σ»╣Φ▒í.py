"""
演示类的定义与对象的创建
"""
class Cat:
    pass

class MyName:
    pass

class Dog:
    pass

cat1 = Cat()
cat2 = Cat()
cat3 = Cat()
