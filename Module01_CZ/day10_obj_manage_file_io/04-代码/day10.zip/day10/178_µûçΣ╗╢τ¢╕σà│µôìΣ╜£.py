"""
演示文件相关操作
"""
import os
# os.rename("壁纸.jpg","178-壁纸.jpg")
# os.rename("178-壁纸.jpg","d:/178-壁纸.jpg")

# os.remove("壁纸-2.jpg")

# os.mkdir("ghi")

os.rmdir("def")