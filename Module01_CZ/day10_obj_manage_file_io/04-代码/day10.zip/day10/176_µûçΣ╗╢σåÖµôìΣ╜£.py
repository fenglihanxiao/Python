"""
演示文件写操作
"""
# file = open("176.txt","w")
# file.write("hello python")
# file.close()

# file = open("176.txt","r")
# lists = file.readlines()
# file.close()
# print(lists)
# file2 = open("176-2.txt","w")
# file2.writelines(lists)
# file2.close()

file = open("176-3.txt","w")
file.write("床前明月光\n")
file.write("疑是地上霜\n")
file.write("举头望明月\n")
file.write("低头思故乡\n")
file.close()