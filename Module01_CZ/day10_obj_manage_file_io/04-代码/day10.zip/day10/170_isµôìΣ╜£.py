"""
演示is操作
"""
# a = "aa;"
# b = "a"+"a;"
# print(a == b)
# print(a is b)

# a = 1
# b = 1.0
# print(a == b)
# print(a is b)

a = [1,2,3]
b = [1,2,3]
print(a == b)
print(a is b)