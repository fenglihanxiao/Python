"""
演示文件的路径
"""
# 绝对路径 
# file = open("D:\\PyCharmProject\\文件管理\\177-2.txt","w")
# file.write("test....")
# file.close()

# 相对路径
file = open("abc\\177-4.txt","w")
file.write("test....")
file.close()