"""
演示引用(数值型、布尔型、字符串型)
"""
# a = 1
# b = 1
# print(id(1))
# print(id(a))
# print(id(b))
# print((id(2)))
# a = 2
# print("-------")
# print(id(a))

# flag1 = True
# flag2 = False
# print(id(flag1))
# print(id(flag2))
# flag1 = False
# print("-------------")
# print(id(flag1))
# print(id(flag2))

str1 = "a"
str2 = "a"
print(id(str1))
print(id(str2))
str1 = "b"
print(id(str1))
print(id(str2))














