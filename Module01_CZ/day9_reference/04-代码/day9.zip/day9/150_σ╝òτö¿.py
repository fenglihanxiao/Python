"""
演示引用
"""
# a = 1
# b = 1
# print(id(1))
# print(id(1))
# print(id(1))
# print(id(a))
# print(id(b))
print(id(1))
print(id(2))
print(id(3))
print(id(4))