# 案例：生成0-9			for i in range(10)
# 请执行程序并分析结果
for i in range(10):
    print(i,end=",")


# 请书写并执行程序，根据结果进行分析
# 案例：生成1-9			for i in range(1, 10)

# 案例：生成1到10之间的偶数		for i in range(0, 10, 2)

# 案例：生成1到10之间的奇数		for i in range(1, 10, 2)

# 案例：生成9-1			for i in range(9, 0, -1)

# 案例：生成9-0			for i in range(9, -1, -1)

