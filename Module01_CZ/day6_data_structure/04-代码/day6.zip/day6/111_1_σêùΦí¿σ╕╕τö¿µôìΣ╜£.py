"""
演示列表常用操作
"""
# list1 = [1,2,3,5,4,6]
# list1.append(10)
# print(list1)
# print(list1.__len__())
# list1.sort()
# print(list1)
# list1.insert(2,"itcast")
# print(list1)

list1 = [1,2,3]
list2 = [6,5,4]
tuple1 = (7,8,9)
set1 = {10,11,12}
list1.extend(list2)
list1.extend(tuple1)
list1.extend(set1)

print(list1)










# list1.append()
# list1.sort()
# list1.__len__()
#
# list1.index()
#
# list1.remove()
# list1.clear()
# list1.insert()
#
# list1.count()
# list1.pop()
# list1.extend()
# list1.reverse()







