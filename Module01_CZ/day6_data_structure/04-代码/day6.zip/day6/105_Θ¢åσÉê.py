"""
演示集合
"""
# set1 = {1,2,3,4,5}
# print(set1)
# for data in set1:
#     print(data)

# set2 = {5,3,2,1,4}
# print(set2[0])

set3 = {True,1,2,3,0,False,4,5,1,2,5}   # 数值非0表示True
print(set3)

if 3:
    print(123)