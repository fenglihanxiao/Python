"""
演示字典
"""
dict1 = {"aa":"aa1","bb":"bb1","cc":"cc1"}
# print(dict1)
# print(dict1["bb"])
# dict1["bb"] = "itcast"
# print(dict1["bb"])
# print(dict1)

for key in dict1:
    print(key)
    print(dict1[key])