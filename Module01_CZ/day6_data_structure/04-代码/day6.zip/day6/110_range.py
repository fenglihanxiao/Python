"""
演示range
"""
# r1 = range(1,5)     # 由1到5，不包含5
# print(list(r1))
# r2 = range(1,10,2)     # 由1到10，不包含10,每次自增2
# print(list(r2))

i= 0
while i<5:
    print("hello")
    i = i+1

for _ in range(3):
    print("hello")

