"""
案例：打印显示多个返回值的函数的结果类型
"""
# 请执行程序，观察并分析结果
def test():
    return 3,4

x = test()

print(x)
print(type(x))