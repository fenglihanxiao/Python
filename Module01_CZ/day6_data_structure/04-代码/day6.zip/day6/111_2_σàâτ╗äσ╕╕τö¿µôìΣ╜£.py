"""
演示元组常用操作
"""
tuple1 = (1,2,3,4,1,2,1)
idx = tuple1.index(3,3,6)
print(idx)
count = tuple1.count(1)
print(count)