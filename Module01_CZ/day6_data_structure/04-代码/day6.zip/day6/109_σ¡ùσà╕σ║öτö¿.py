"""
演示字典及应用
"""
class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

p1 = Person("大帅",20)

dict1 = {"name":"大帅","age":20}