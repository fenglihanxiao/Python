"""
演示列表
"""
list1 = [1,2,3,'itcast',"heima",True,False,None]
# print(list1)
# print(list1[4])
# list1[4] = "黑马程序员"
# print(list1[4])

for data in list1:
    print(data)