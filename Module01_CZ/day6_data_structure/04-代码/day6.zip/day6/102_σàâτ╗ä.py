"""
演示元组
"""
tuple1 = (1,2,3,"itcast","黑马程序员",True,False)
print(tuple1)
tuple2 = (100,)
print(tuple2)
# tuple3 = ("itcast") #不是元组
# print(type(tuple3))
# print(tuple1[4])
# tuple1[4] = "heima"
for data in tuple1:
    print(data)