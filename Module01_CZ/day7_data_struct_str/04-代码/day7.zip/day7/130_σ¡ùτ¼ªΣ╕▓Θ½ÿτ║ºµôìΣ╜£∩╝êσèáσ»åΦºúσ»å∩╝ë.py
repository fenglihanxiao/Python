"""
演示字符串加密解密操作
"""
# str1 = "say goodbye"
# dict1 = "".maketrans("abcdefg","1234567")
# # print(dict1)
# str2 = str1.translate(dict1)
# print(str2)

# str3 = "s1y 7oo42y5"
# dict2 = "".maketrans("1234567","abcdefg")
# str4 = str3.translate(dict2)
# print(str4)



# str1 = "say g77dbye"        # s1y 77742y5
# dict1 = "".maketrans("abcdefg","1234567")
# # print(dict1)
# str2 = str1.translate(dict1)
# print(str2)
#
# str3 = "s1y 77742y5"
# dict2 = "".maketrans("1234567","abcdefg")
# str4 = str3.translate(dict2)
# print(str4)

dict1 = "".maketrans("abcdefg","1234567")
dict2 = "".maketrans("1234567","bcdefgh")
dict3 = "".maketrans("cdefghi","1234567")
dict4 = "".maketrans("1234567","defghij")


