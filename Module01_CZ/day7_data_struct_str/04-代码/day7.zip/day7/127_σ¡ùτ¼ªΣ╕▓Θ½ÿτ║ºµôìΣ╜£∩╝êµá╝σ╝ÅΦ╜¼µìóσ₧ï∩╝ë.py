"""
演示字符串格式转换型操作
"""
# str1 = " 张三丰 男 100岁 "
str1 = " 张三丰  "
s = str1.strip()
print(len(s))






