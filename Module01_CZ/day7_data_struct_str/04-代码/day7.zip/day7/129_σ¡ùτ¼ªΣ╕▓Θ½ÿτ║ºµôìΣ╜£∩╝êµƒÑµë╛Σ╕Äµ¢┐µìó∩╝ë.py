"""
演示字符串格查找与替换操作
"""
str1 = "hello python"
# print(str1.find("hi"))
# print(str1.index("hi"))

str2 = str1.replace("o","itcast")
print(str2)
