"""
演示字符串判断型操作
"""
# str1 = "\n"
# print(str1.islower())
# print(str1.isupper())

name = "张三丰"
print(name.startswith("张三"))

filename="1.jpge"
if filename.endswith(".jpg") or filename.endswith(".png") :
    print("该文件是一个图片")

