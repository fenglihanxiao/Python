"""
演示字符串基本操作
"""
str1 = "hello,黑马程序员带你走进python的世界"
print(len(str1))
print(str1[6])
print(min(str1))
