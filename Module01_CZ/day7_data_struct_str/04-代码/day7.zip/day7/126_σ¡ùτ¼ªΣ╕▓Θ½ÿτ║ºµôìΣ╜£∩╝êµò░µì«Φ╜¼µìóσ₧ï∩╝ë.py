"""
演示字符串数据转换型操作
"""
str1 = "heima chengxuyuan IT 培训领航者"

print(str1.upper())


