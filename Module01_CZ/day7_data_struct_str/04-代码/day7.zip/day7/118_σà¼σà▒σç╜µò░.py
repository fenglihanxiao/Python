"""
演示公共函数len,max,min
"""
list1 = [1,2,3,4,5,6]
tuple1 = (1,2,3,4,5,6)
set1 = {1,2,3,4,5,6,5,6}
dict1 = {1:"aa",2:"bb",3:"cc",4:"dd"}

print(len(dict1))
print(max(dict1))
print(min(dict1))
