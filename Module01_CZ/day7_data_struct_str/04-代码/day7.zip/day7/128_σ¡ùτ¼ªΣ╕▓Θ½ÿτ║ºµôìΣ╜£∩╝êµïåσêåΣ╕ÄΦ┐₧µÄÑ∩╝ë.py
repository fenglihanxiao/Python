"""
演示字符串拆分与连接操作
"""
# str1 = "张三,男,18,178,74"
# list1 = str1.split(",")
# print(list1)

print("hello "+"python")


