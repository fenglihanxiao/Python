"""
演示运算符
"""
list1 = [1,2,3]
list2 = [4,5,6]
tuple1 = (1,2,3)
tuple2 = (4,5,6)
set1 = {1,2,3,4}
set2 = {3,4,5,6}
dict1 = {1:"aa",2:"bb",3:"cc",4:"dd"}

# print(list1 + list2)
# print(list1 * 4)
# print(4 in dict1 )

# list4 = [2,1,2,1,2,3]
# list5 = [2,1,3]
# print(list4 < list5)

set3 = {2,1,3}
set4 = {4,1,2}
print(set3 > set4)