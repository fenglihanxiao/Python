"""
演示字符串创建与基本操作
"""
str1 = "双引号\"包裹的\"字符串"
str2 = '单引号\'包裹的\"字符串'
str3 = """3个双引号包裹的字符串"""
str4 = '''3个单引号包裹的字符串'''
str5 = """3个
双引号
包裹的
字符串"""
print(str1)
print(str2)
print(str3)
print(str4)
print(str5)