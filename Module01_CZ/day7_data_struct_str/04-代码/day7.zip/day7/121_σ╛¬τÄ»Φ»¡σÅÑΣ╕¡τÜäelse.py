"""
演示循环语句中的else
"""
for data in range(5):
    print(data)
    if data == 3 :
        break
else:
    print("end")

print("结束")