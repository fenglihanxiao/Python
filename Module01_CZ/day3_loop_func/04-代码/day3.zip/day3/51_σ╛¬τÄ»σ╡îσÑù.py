"""
演示循环嵌套
"""
j = 1
while j <= 5:
    i = 1
    while i <= 3:
        print(i)
        i += 1
    j += 1