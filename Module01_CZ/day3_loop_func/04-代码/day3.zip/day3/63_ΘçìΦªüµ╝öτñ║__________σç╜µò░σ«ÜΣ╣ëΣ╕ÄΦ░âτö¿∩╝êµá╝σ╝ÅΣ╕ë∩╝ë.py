"""
案例：改造函数pow2，将其运行结果使用返回值传递出去
"""
def pow2(a):
    c = a ** 2
    print(c)

pow2(15)
