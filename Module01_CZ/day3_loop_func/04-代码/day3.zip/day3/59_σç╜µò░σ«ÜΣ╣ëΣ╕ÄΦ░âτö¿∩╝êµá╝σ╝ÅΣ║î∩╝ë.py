"""
演示带参数的函数定义与调用
定义格式：
def 函数名(参数):
    函数体
调用格式：
函数名(参数)
"""


# def sum(a):  # a = 100
#     """用于计算1到指定数字的和"""
#     i = 1
#     sums = 0
#     while i <= a:
#         sums += i
#         i += 1
#     print(sums)
#
#
# sum(10)


def add(a,b):
    print(a+b)

add(3,4)