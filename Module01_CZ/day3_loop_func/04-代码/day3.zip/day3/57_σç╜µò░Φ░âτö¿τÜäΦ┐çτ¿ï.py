"""
演示函数的调用过程
"""
print("开始")

def say():
    print("1")
    print("2")
    print("小结")


say()
print("函数第一次执行完毕")
say()
say()
print("结束")