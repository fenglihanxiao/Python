"""
案例：定义函数hi()完成下列内容输出
	hello world
	hello python
	hello itcast
"""
