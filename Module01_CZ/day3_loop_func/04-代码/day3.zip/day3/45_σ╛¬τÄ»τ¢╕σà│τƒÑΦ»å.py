"""
演示while循环相关知识
1.循环变量控制：从0开始
2.死循环
"""
i = 0
while i < 5:
    print("hello python")
    i += 1
print("结束")




