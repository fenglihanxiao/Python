"""
演示函数的定义与调用
定义格式：
def 函数名():
    函数体
调用格式：
函数名()
"""

def say():
    print("hello 北京")
    print("hello 中国")
    print("hello python")

say()
say()
say()