"""
演示while循环语句
"""
# 通常使用循环变量来控制循环的执行次数
i = 1
# 循环从while开始，后面添加条件
while i <= 3:
    # while下面添加要反复执行的语句
    print("hello python")
    i += 1





