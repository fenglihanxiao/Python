"""
演示形参与实参
TypeError: add() takes 2 positional arguments but 3 were given
TypeError: add() missing 1 required positional argument: 'b'
"""

def add(a,b):
    print(a+b)

add(1,2,3)














