"""
演示字典参数格式混用
"""
# def test(a,*args,m=1, **kwargs):
#     print(kwargs)

def test(m,**kwargs):
    print(m)
    print(kwargs)

test(x=1,y=2,m=1)