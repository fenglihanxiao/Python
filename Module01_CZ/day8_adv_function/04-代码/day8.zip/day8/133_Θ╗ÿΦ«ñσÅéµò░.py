"""
演示默认参数
"""
def test( a , b , *args , c = 1 ):
    pass



