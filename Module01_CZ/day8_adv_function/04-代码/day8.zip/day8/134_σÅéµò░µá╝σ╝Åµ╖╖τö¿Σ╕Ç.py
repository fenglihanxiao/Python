"""
演示默认参数与位置参数混用
"""
# def test(c=100,d=200,e=300):
#     print(c)
#     print(d)
#     print(e)
# test(3)

# def test( a, b = 100):
#     print(a)
#     print(b)
# test(1)












def test(a,b,c=100,d=200):
    print(a)
    print(b)
    print(c)
    print(d)

test(1,2,3)

