"""
演示关键字参数
"""
def test(a = 100,b = 200 ):
    print(a)
    print(b)

test(b=1)