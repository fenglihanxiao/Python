"""
演示关键字参数格式混用
"""
# def test(a =100,b=200):
#     print(a)
#     print(b)
# test(b=2,a=1)

# def test( a,b):
#     print(a)
#     print(b)
# test(1,a = 1)

def test(a,b):
    print(a)
    print(b)
test(1,a = 1)

