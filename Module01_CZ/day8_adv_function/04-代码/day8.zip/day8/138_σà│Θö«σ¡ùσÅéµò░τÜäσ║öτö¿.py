"""
演示关键字参数应用
"""
print("hello",end=" ")
print("itcast",end=" ")
print("python")
