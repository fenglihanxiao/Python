"""
演示构造异常现象
"""
# x = 1
# # y = 0
# # # 检查y是不是0
# # if y == 0 :
# #     # 抛出具体的异常
# #     raise ZeroDivisionError("division by zero")
# # # b = x/y

raise ValueError("你就是猜不到我这是个什么异常")
