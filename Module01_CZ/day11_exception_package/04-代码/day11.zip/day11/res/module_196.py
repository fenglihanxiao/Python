a = 1
b = 100
print(a)