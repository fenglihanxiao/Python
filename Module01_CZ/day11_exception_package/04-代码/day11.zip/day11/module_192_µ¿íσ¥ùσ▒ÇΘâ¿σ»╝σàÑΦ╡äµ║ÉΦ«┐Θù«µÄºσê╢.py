"""
演示模块局部导入资源访问控制
"""
# from module_192 import *
# show()
# print(age)

from module_192 import module
print(module)