"""
演示异常处理方案三
"""
print("程序开始")

try:
    # a = 1
    print(a)
except:
    print("呵呵")
else:
    print("打印a成功")

print("程序结束")
