"""
演示模块的定义
"""
class Cat:
    @classmethod
    def speak(cls):
        print("猫叫")

def show():
    print("hello module")

module = [1,2,3]
age = 18