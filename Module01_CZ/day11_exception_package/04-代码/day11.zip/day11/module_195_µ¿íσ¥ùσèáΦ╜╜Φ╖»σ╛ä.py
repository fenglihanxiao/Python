"""
演示模块加载路径
"""
import random
import sys
print(sys.path)
# sys.path.append("msg")
# print(sys.path)