"""
演示模块全部导入
"""
import module_189
import random

# module_189.show()
# print(module_189.age)
# print(module_189.module)
# c = module_189.Cat()
# print(c)

print(random.randint(1,3))