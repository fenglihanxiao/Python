"""
演示模块运行代码管理
"""
import module_193

# print("测试代码")

# print(__name__) # __main__