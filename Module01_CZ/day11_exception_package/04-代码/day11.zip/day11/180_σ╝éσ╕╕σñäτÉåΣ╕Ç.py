"""
演示异常处理方案一
"""
print("程序开始")

try:
    # a = 1
    print(a)
    print("打印a成功")
except:
    print("呵呵")

print("程序结束")


