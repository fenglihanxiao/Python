class NameQuestion(Exception):
    pass
class PasswordQuestion(Exception):
    pass