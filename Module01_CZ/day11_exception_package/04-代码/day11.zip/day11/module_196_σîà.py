"""
演示包
"""
# import res.module_196
# # print(res.module_196.b)

# from res.module_196 import b
# print(b)

