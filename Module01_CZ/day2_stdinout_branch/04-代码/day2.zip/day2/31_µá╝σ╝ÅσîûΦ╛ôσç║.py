"""
演示数据的格式化输出
"""
# print("hello python")
name = "张三"
age = 22
hight = 1.78
print("姓名是%s，年龄是%d岁，身高%.2f米,成绩是全校前20%%" % (name, age, hight))
