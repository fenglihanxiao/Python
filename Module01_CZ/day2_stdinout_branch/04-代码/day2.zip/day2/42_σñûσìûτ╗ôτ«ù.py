"""
案例：外卖结算
要求：满30减10块，满50减20，满100减50，会员折上再8折。
"""
# 分析
# 1.输入的数据有两个，1是价格（小数)，2是会员资格(布尔)
# 2.满减活动分4种情况，选择if..elif..else结构
# 3.在每种情况中做一件事，就是价格发生变化

price = float(input("请输入您采购的东西总价："))
member = input("请输入您是否是会员（是或否）：")

if price >= 100:
    # price = price - 50
    price -= 50
elif price >= 50:
    price -= 20
elif price >= 30:
    price -= 10

if member == "是":
    price *= 0.8

print("您的最终账单价格是%.2f元" % price)