"""
案例：减肥计划
要求：输入星期数，显示今天的减肥活动
	周一：跑步       周二：游泳     周三：健身房
	周四：动感单车   周五：拳击     周六：爬山
	周日：好好吃一顿
"""
# 分析
# 1.键盘输入一个数字，表示今天是星期几。int str?都可以
# 2.分7种情况，选择if..elif..else语法结构，写6个条件，最后一个用else
# 3.每种情况中按照要求打印即可

week = int(input("请输入今天是星期几："))
if week == 1:
    print("跑步")
elif week == 2:
    print("游泳")
elif week == 3:
    print("健身房")
elif week == 4:
    print("动感单车")
elif week == 5:
    print("拳击")
elif week == 6:
    print("爬山")
else:
    print("大吃一顿")