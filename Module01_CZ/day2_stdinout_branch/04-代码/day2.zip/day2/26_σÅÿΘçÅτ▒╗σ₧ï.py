"""
变量类型
"""
# # int integer 整型
# age = 18
# # float 小数
# height = 1.80
# # bool boolean 布尔型  True(1) False(0)
# flag = True
# # str string 字符串
# name = "张三丰"

age = 18
print(type(age))
age = 18.0
print(type(age))
age = "18"
print(type(age))
age = True
print(type(age))

print("结束")
