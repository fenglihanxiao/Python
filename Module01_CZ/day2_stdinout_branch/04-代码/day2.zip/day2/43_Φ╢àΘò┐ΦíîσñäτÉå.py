"""
演示超长行处理
"""
# 解决方案1：在连续书写的内容空格位置敲回车，会自动补入一个\，表示当前行没有书写完毕，连接下一行
# x = 20
# if x == 5 and x == 5 and x == 5 and x == 5 and x == 5 \
#         and x == 5 and x == 5 and x == 5 and x == 5 and \
#         x == 5 and x == 5 and x == 5 and x == 5 and x == 5:
#     print("ok")

# 解决方案1：对于连续的独立的内容两端添加()，在括号内就可以任意换行，保持原始输入单元独立即可
x = 20
if (x == 5 and x == 5 and
        x == 5 and x
        == 5 and
        x == 5 and x ==
        5 and x == 5 and x == 5
        and x == 5 and x == 5 and x == 5 and x == 5
        and x == 5 and x == 5):
    print("ok")