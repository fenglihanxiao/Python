"""
演示关系运算符的基本操作
关系运算是在两个布尔值之间做运算的
三种关系运算符
and:并且      or:或者       not:非
"""
# money = True
# offer = False
# print(money and offer)

# train = False
# bus = False
# bike = True
# print(train or bus or bike)

flag = True
print(not flag)
