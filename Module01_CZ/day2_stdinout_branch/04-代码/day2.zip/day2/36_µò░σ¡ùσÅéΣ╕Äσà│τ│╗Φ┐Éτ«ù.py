"""
演示数字参与关系运算
True(1)  False(0)
"""
# print(1 and True)
# print(0 or False)

# print(-2 and True)

# 逻辑 and 逻辑
# 参看真值表，16字口诀

# 数字 and 逻辑
# print(1 and True)   # True
# print(0 and True)   # 0
# print(0 or False)   # False
# print(2 or False)   # 2

# 逻辑 and 数字
# print(True and 1)   # 1
# print(True and 0)   # 0
# print(False or 0)   # 0
# print(False or 2)   # 2

# 数字 and 数字
print(1 and 2)   # 2
print(1 and 0)   # 0
print(0 or 0)   # 0
print(0 or 2)   # 2
print("分割线")
print(0 and 1)   # 0
print(2 or 0)   # 2

