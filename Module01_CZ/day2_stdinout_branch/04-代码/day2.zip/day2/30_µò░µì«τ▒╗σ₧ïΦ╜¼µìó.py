"""
演示数据类型转换的使用
演示输入数据转换类型的使用
"""
# 使用input操作得到的数据都是字符串str类型的
# s = input("输入数据：")
# print(type(s))

# 需求：计算a+b的值，要求a与b都通过键盘输入
# 通过类型转换，将字符串转换为数字
# a = float(input("输入数字："))
# b = float(input("输入数字："))
# print(a + b)

#思考：类型转换如果不匹配的问题
a = float(input("输入："))
print(a)
