"""
演示标准输入函数input()的使用
"""
# input()可以用来接收用户输入的信息，当执行到input()操作时，程序等待用户输入，而不向下执行
# 第一种格式：input()
# name = input()
# print(name)

# 第二种格式：input("信息")
name = input("请输入你的姓名:")
print(name)