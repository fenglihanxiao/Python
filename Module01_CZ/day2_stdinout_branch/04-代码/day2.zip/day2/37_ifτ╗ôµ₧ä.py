"""
演示if结构分支语句
"""
# print("开始")
# print("进行")
# if False:
#     print("分支运行中")
# print("结束")

# x = 150
# if x > 100:
#     print(x)
# print("结束")

# x = -50
# if x > 0 and x < 100:
#     print(x)
# print("结束")

x = 50
if x > 100:
    print(x)
print(x)
print(x)
print("结束")
