"""
演示if..else..结构分支语句
"""
# 判断两个数字哪个是大的数字，并打印
# a = 2
# b = 10
# if a >= b:
#     print(a)
# else:
#     print(b)

# 判断一个数字是不是偶数
x = 372
if x % 2 == 0 :
    print("这是个双数")
else:
    print("这是个单数")
