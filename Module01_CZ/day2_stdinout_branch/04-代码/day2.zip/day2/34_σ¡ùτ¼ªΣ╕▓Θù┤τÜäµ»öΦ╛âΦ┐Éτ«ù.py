"""
字符串间的比较运算
数字：0<1<2<3...<8<9
字母：a<b<c<...<y<z
大写字母<小写字母
"""
# name1 = "A"
# name2 = "a"
# print(name1 < name2)

name1 = "ab"
name2 = "abd"
print(name1 < name2)




