"""
演示比较运算符的基本操作
"""
score1 = 100
score2 = 100
print(score1 != score2)
