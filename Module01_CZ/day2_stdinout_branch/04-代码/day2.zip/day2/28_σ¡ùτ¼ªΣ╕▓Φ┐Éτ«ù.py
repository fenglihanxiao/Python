"""
字符串运算
"""
name = "张三丰"
first_name = "张"
last_name = "三丰"
# +号可以将两个字符串连接在一起
print(first_name + last_name)
# 字符串不能与数字相连接，只能与字符串相连接
# print(name + 3)
# 字符串可以使用*与数字相连，表示反复连接多个字符串，连接的数量是*后面的数字
print(name * 3)



