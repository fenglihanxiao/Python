"""
演示if..elif..else..结构分支语句
"""
# 考试出分以后...
score = 73
if score == 100:
    print("买自行车，可拉风了")
elif score >= 95 and score < 100:
    print("去游乐场玩，可HAPPY了")
elif score >= 90 and score < 95:
    print("买玩具，你们都没有")
elif score >= 80 and score < 90:
    print("没事，哥还活着")
else:
    print("小心你的屁屁")
print("结束")