"""
变量：用于保存计算机中的数据
定义格式：变量名 = 值
"""
age = 18
height = 1.80
weight = 80.0

age = 19
weight = 82.0


