"""
当前代码的作用是演示注释的功能
"""
print(1)
print(2)
# TODO 等到程序做完了再回来优化这一段代码，可以调高效果40%，具体的优化方案......
print(3)
print(4)
# TODO 你猜我想干什么
print(5)

# 测试信息
print("itcast")








