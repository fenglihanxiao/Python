"""
变量的使用：使用变量中的数据时直接使用变量名即可
使用/调用格式：变量名
"""
# age = 18
# print(age)
# age = 19
# print(age)

a = b = 1
print(b)
b = 2
print(a)

