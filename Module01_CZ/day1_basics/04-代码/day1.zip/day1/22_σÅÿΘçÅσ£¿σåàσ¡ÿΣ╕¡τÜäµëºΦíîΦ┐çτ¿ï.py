"""
演示：c=a+b
"""
a = 3
b = 2
c = a + b
print(c)
print("结束")

